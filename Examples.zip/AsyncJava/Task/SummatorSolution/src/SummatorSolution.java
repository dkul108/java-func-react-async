import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class SummatorSolution {
    static CompletableFuture<Integer> process(String data) {
        return CompletableFuture.completedFuture(
                Arrays.asList(data.split(" ")).stream()
                .mapToInt(Integer::parseInt)
                .sum()
        );
    }

    public static void main(String[] args) throws IOException {
        String[] files = AsyncFiles.listFilesInFolder(".", "txt");

        // to improve performance, we should sort files by its size
        // to start processing the largest files first

        CompletableFuture<Integer> future = null;
        for (int i=0;i<files.length;i++) {
            System.out.println(files[i]+" is processing");
            CompletableFuture<Integer> nextFuture =
                    AsyncFiles.readFromFile(files[i])
                    .thenApply(String::trim)
                    .thenComposeAsync(SummatorSolution::process)
                    .exceptionally(e->{
                        if (e.getCause() instanceof NumberFormatException) return 0;
                        else throw new RuntimeException("exception in CF", e.getCause());
                    });
            if (future!=null) {
                future = future
                        .thenCombine(nextFuture, (x,y)->x+y);
            } else future = nextFuture;
        }

        future.thenAccept(res-> {
            System.out.println("processing done with result = " + res);
        });

        future.thenAccept(res->
                AsyncFiles.writeToFile("result.dat", res.toString()))
            .join();
        }
}
