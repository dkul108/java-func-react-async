import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Function;

/**
 * TASK:
 * <p>
 * Create summator for all data in .txt files in project folder.
 * Files contains integer numbers separated by spaces
 * (there could be trailing spaces which could be removed with String.trim).
 * In case of error in file (NumberFormatException) file should be ignored.
 * Result should be saved to file result.dat.
 * Result should be 2800, 5.txt should be ignored.
 */
public class SummatorSolutionReduce {

    static CompletableFuture<Integer> process(String data) {
        return CompletableFuture.completedFuture(
                Arrays.asList(data.split(" ")).stream()
                        .mapToInt(Integer::parseInt)
                        .sum()
        );
    }

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {

        // Here you can find the demonstration of already implemented methods

        // use AsyncFiles.listFilesInFolder to get list of all files
        String[] files = AsyncFiles.listFilesInFolder(".", "txt");
        Arrays.asList(files).forEach(System.out::println);

        // use Summator.process to calculate the sum of all values in file
        // execute it in separate thread (use Async)

        CompletableFuture<Integer> fu = Arrays.stream(files)
                .map(file -> AsyncFiles.readFromFile(file)
                        .thenApply(String::trim)
                        .thenComposeAsync(SummatorSolutionReduce::process)
                        .exceptionally(throwable -> 0)) // todo check numberformat exception
                .reduce(CompletableFuture.supplyAsync(() -> 0),
                        (fu1, fu2) -> fu1.thenCombineAsync(fu2, (x, y) -> x + y))
                ;

        fu.thenAccept(System.out::println); // for debugging

        AsyncFiles.writeToFile("result.dat", fu.get().toString())
                .join();

    }

    private static String mergeIntoOneLine(String x, String y) {
        return (x + " " + y).trim();
    }
}
