import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class AsyncCompletableClient {

    public static void main (String [] args)
            throws IOException, InterruptedException, ExecutionException {

        AsynchronousSocketChannel server = AsynchronousSocketChannel.open();
        InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
        Future future = server.connect(hostAddress);
        future.get(); // returns null

        System.out.println("Client is started: " + server.isOpen());
        System.out.println("Sending messages to server: ");

        try( BufferedReader r = new BufferedReader(new InputStreamReader(System.in))){

            // Show menu
            String msg = null;
            ByteBuffer rbuf = ByteBuffer.allocate(64);
            server.read(rbuf).get();
            msg = new String(rbuf.array()).trim();
            System.out.println(msg);

            // Dialog
            Future result;
            while (true){
                msg = r.readLine();
                ByteBuffer buffer = ByteBuffer.wrap(msg.getBytes());
                server.write(buffer).get();

                rbuf.clear();
                result = server.read(rbuf);
                int len = (Integer)result.get();
                msg = new String(rbuf.array(), 0, len).trim();
                System.out.println(msg);
                if ("bye".equals(msg)) break;

                buffer.clear();
            }
        }


        server.close();
    }
}