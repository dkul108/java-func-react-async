
import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.CompletableFuture;

public class AsyncCompletableClient3 {

    static InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);

    public static CompletableFuture<Void> dialog(AsynchronousSocketChannel channel) {
        String choice = NioCF.readConsole();
        return NioCF.write(choice, channel)
                .thenCompose((Void v) -> NioCF.read(channel))
                .thenCompose(res -> {
                    System.out.println(res); // print server answer
                    if ("bye".equals(res)) {
                        NioCF.close(channel);  // finish this client
                        return CompletableFuture.completedFuture(null);
                    } else {
                        return dialog(channel);
                    }
                });
    }

    public static CompletableFuture<Void> connectSever() {
        try {
            AsynchronousSocketChannel channel = AsynchronousSocketChannel.open();
            return NioCF.connect(channel, hostAddress)
                    .thenCompose((Void v)->NioCF.read(channel))
                    .thenAccept(System.out::println)
                    .thenCompose((Void v) -> dialog(channel));

        } catch (Exception e) {
            e.printStackTrace();
            return CompletableFuture.completedFuture(null);
        }
    }

    public static void main (String [] args)
            throws Exception {
        connectSever().get();
    }
}