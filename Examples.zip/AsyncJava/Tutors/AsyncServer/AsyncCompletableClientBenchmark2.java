import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class AsyncCompletableClientBenchmark2 {

    public static void main (String [] args)
            throws IOException, InterruptedException, ExecutionException {
        ExecutorService executorService = Executors.newFixedThreadPool(20);

        AtomicInteger processedClients = new AtomicInteger(0);
        InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
        Runnable runnable = () -> {
            try {
                AsynchronousSocketChannel server = AsynchronousSocketChannel.open();
                Future future = server.connect(hostAddress);
                try {
                    future.get(); // returns null
                } catch(ExecutionException e) {
                    System.out.println("CAN'T CONNECT");
                    return;
                }
                //System.out.println("Client is started: " + server.isOpen());
                //System.out.println("Sending messages to server: ");

                try (BufferedReader r = new BufferedReader(new InputStreamReader(System.in))) {

                    // Show menu
                    String msg = null;
                    ByteBuffer rbuf = ByteBuffer.allocate(64);
                    server.read(rbuf).get();
                    msg = new String(rbuf.array()).trim();
                    //System.out.println(msg);

                    // Dialog
                    Future result;
                    while (true) {
                        //msg = r.readLine();
                        msg = "2";
                        ByteBuffer buffer = ByteBuffer.wrap(msg.getBytes());
                        server.write(buffer).get();

                        rbuf.clear();
                        result = server.read(rbuf);
                        int len = (Integer) result.get();
                        msg = new String(rbuf.array(), 0, len).trim();
                        //System.out.println(msg);
                        if ("bye".equals(msg)) break;

                        buffer.clear();
                    }
                }

                server.close();
                processedClients.incrementAndGet();

            } catch (Exception e) {
                if (!executorService.isShutdown()) {
                    System.out.println("EXCEPTION AT CLIENT "+processedClients.get());
                    e.printStackTrace();
                    executorService.shutdownNow();
                }

            }
        };

        for (int i = 0; i < 20000; i++) {
            if (!executorService.isShutdown()) {
                executorService.submit(runnable);
                //Thread.sleep(10);
            }
        }

        executorService.awaitTermination(200, TimeUnit.SECONDS);
        System.out.println("Server processed "+processedClients.get()+" clients");
    }
}