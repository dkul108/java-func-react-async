
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicInteger;

public class AsyncCompletableClientBenchmark3 {

    static AtomicInteger processedClients = new AtomicInteger(0);
    static InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
    volatile static boolean shouldStop = false;

    public static CompletableFuture<Void> dialog(AsynchronousSocketChannel channel) {
        String choice = "2"; // readConsole();
        return NioCF.write(choice, channel)
                .thenCompose((Void v) -> NioCF.read(channel))
                .exceptionally(e->{
                    e.printStackTrace();
                    shouldStop = true;
                    return null;
                })
                .thenCompose(res -> {
                    //System.out.println(res); // print server answer
                    if (shouldStop) return CompletableFuture.completedFuture(null);
                    if ("bye".equals(res)) {
                        processedClients.incrementAndGet();
                        NioCF.close(channel);  // finish this client
                        return nextClient();
                        //return CompletableFuture.completedFuture(null);
                    } else {
                        return dialog(channel);
                    }
                });
    }

    public static CompletableFuture<Void> nextClient() {
        try {
            AsynchronousSocketChannel channel = AsynchronousSocketChannel.open();
            return NioCF.connect(channel, hostAddress)
                    .thenCompose((Void v)->NioCF.read(channel))
                    .exceptionally(e->{
                        System.out.println("AFTER CONNECT in nextClient");
                        //e.printStackTrace();
                        shouldStop = true;
                        return null;
                        //throw new RuntimeException("F*CK");
                    })
                    .thenCompose(menu -> dialog(channel));

        } catch (Exception e) {
            e.printStackTrace();
            return CompletableFuture.completedFuture(null);
        }
    }


    public static void main (String [] args)
            throws IOException, InterruptedException, ExecutionException {
        nextClient().get();

        System.out.println("Server processed "+processedClients.get()+" clients");
    }
}