import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * Task: Use CompletionHandler and CompletableFuture for AsyncServer
 * Implement possibility to use menu to retrieve information from the server:
 * 1) Get current time
 * 2) Exit
 *
 * Get numbers from clients until client will send Bye. Print its sum.
 *
 * Task 2: implement multithreaded server
 */
public class AsyncCompletableServer {

    public static void writeToClient(String msg, AsynchronousSocketChannel clientChannel){
        CompletableFuture<Void> futureWrite = new CompletableFuture<>();

        ByteBuffer buffer = ByteBuffer.wrap(msg.getBytes());
        clientChannel.write(buffer, null, new CompletionHandler<Integer, Void>() {
            @Override
            public void completed(Integer result, Void attachment) {
                futureWrite.complete(null);
            }

            @Override
            public void failed(Throwable exc, Void attachment) {
                futureWrite.completeExceptionally(exc);
            }
        });

        try {
            //можем делать что-то другое, но ничего не надо, роэтому ждем
            futureWrite.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public static void main (String [] args)
            throws ExecutionException, InterruptedException, IOException {

        CompletableFuture<AsynchronousSocketChannel> futureSocket = new CompletableFuture<>();

        AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open();
        InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
        serverChannel.bind(hostAddress);

        System.out.println("Server channel bound to port: " + hostAddress.getPort());
        System.out.println("Waiting for client to connect... ");

        serverChannel.accept(null,
                new CompletionHandler<AsynchronousSocketChannel, Void>() {
                    @Override
                    public void completed(AsynchronousSocketChannel result, Void attachment) {
                        futureSocket.complete(result);
                    }

                    @Override
                    public void failed(Throwable exc, Void attachment) {
                        futureSocket.completeExceptionally(exc);
                    }
                });

        futureSocket.thenAccept(clientChannel->{
            System.out.println("Messages from client: ");

            if ((clientChannel != null) && (clientChannel.isOpen())) {

                while (true) {
                    ByteBuffer buffer = ByteBuffer.allocate(64);
                    CompletableFuture<String> futureMsg = new CompletableFuture<>();

                    writeToClient("1) Get current time\n2) Exit\n", clientChannel);

                    clientChannel.read(buffer, buffer, new CompletionHandler<Integer, ByteBuffer>() {
                        @Override
                        public void completed(Integer result, ByteBuffer buf) {
                            buf.flip();
                            String message = new String(buf.array()).trim();
                            futureMsg.complete(message);
                        }

                        @Override
                        public void failed(Throwable exc, ByteBuffer attachment) {
                            futureMsg.completeExceptionally(exc);
                        }
                    });

                    String msg = null;
                    try {
                        msg = futureMsg
                                .thenApply((String m)-> {
                                    System.out.println(m);
                                    return m;
                                }).get();//можем делать что-то другое, но ничего не надо, поэтому ждем
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }

                    if (msg.equals("Bye.") || msg.equals("2")) break; // while loop

                    if(msg.equals("1")){
                        writeToClient(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss\n")), clientChannel);
                    }

                    buffer.clear();
                } // while()
                try {
                    clientChannel.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } // end-if
        }).thenRun(()->{
            try {
                serverChannel.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }).get();
    }
}