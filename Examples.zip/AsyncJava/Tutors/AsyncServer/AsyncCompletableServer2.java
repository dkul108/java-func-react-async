import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannel;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

/**
 * Task: Use CompletionHandler and CompletableFuture for AsyncServer
 * Implement possibility to use menu to retrieve information from the server:
 * 1) Get current time
 * 2) Exit
 *
 */
public class AsyncCompletableServer2 {

    public static CompletableFuture<Void> writeToClient(String msg, AsynchronousSocketChannel clientChannel){
        CompletableFuture<Void> futureWrite = new CompletableFuture<>();

        ByteBuffer buffer = ByteBuffer.wrap(msg.getBytes());
        clientChannel.write(buffer, null, new CompletionHandler<Integer, Void>() {
            @Override
            public void completed(Integer result, Void attachment) {
                futureWrite.complete(null);
            }

            @Override
            public void failed(Throwable exc, Void attachment) {
                futureWrite.completeExceptionally(exc);
            }
        });

        return futureWrite;
    }

    public static CompletableFuture<String> readFromClient(AsynchronousSocketChannel clientChannel) {
        ByteBuffer buffer = ByteBuffer.allocate(64);
        CompletableFuture<String> futureMsg = new CompletableFuture<>();

        clientChannel.read(buffer, buffer, new CompletionHandler<Integer, ByteBuffer>() {
            @Override
            public void completed(Integer result, ByteBuffer buf) {
                buf.flip();
                String message = new String(buf.array()).trim();
                futureMsg.complete(message);
            }

            @Override
            public void failed(Throwable exc, ByteBuffer attachment) {
                futureMsg.completeExceptionally(exc);
            }
        });
        return futureMsg;
    }

    public static CompletableFuture<AsynchronousSocketChannel> acceptClient(
            AsynchronousServerSocketChannel serverChannel) {
        CompletableFuture<AsynchronousSocketChannel> futureSocket = new CompletableFuture<>();
        serverChannel.accept(null,
                new CompletionHandler<AsynchronousSocketChannel, Void>() {
                    @Override
                    public void completed(AsynchronousSocketChannel result, Void attachment) {
                        futureSocket.complete(result);
                    }
                    @Override
                    public void failed(Throwable exc, Void attachment) {
                        futureSocket.completeExceptionally(exc);
                    }
                });
        return futureSocket;
    }

    public static void closeChannel(AsynchronousChannel clientChannel) {
        try {
            clientChannel.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    static String MENU = "1) Get current time\n2) Exit\n";
    static AtomicInteger clientsAmount = new AtomicInteger(0);

    public static CompletableFuture<Void> nextClient(AsynchronousServerSocketChannel serverChannel) {
        return acceptClient(serverChannel)
                .thenAccept(clientChannel -> {
                    writeToClient(MENU, clientChannel)
                        .thenCompose((Void v) -> dialog(clientChannel));
                })
                .thenRun(()-> System.out.println("Client "
                        +clientsAmount.incrementAndGet()+" connected"))

                // also we are able to use recursion instead of while(true)
                .thenComposeAsync((Void v)->nextClient(serverChannel));
    }

    public static CompletableFuture<Void> dialog(AsynchronousSocketChannel clientChannel) {
            return readFromClient(clientChannel) // read menu choice
                   .thenCompose(msg->{
                       if ("2".equals(msg)) {
                           return writeToClient("bye", clientChannel)
                                   .thenRun(()-> {
                                       System.out.println("Client disconnected");
                                       closeChannel(clientChannel);
                                   });
                       } else {
                           String response = "wrong command";
                           if ("1".equals(msg))
                               response = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                           response += "\n"+MENU;
                           return writeToClient(response, clientChannel)
                                   .thenCompose((Void v) -> dialog(clientChannel));
                       }
                   });
    }

    public static void main (String [] args)
            throws ExecutionException, InterruptedException, IOException {

        try(AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open()) {
            InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
            serverChannel.bind(hostAddress);
            System.out.println("Server channel bound to port: " + hostAddress.getPort());

            // if we would use recursion instead of while(true)
            nextClient(serverChannel).get();

            //while (true) {
            //    nextClient(serverChannel).get();
            //}


        }

    }
}