import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class AsyncCompletableServer3 {

    static String MENU = "1) Get current time\n2) Exit\n";

    private static CompletableFuture<Void> nextClient(AsynchronousServerSocketChannel serverChannel) {
        return NioCF.acceptClient(serverChannel)
                .thenAccept(clientChannel -> {
                    NioCF.write(MENU, clientChannel)
                        .thenCompose((Void v) -> dialog(clientChannel));
                })

                // also we are able to use recursion instead of while(true)
                .thenCompose((Void v)->nextClient(serverChannel));
    }

    private static CompletableFuture<Void> dialog(AsynchronousSocketChannel clientChannel) {
            return NioCF.read(clientChannel) // read menu choice
                   .thenCompose(msg->{
                       if ("2".equals(msg)) {
                           return NioCF.write("bye", clientChannel)
                                   .thenRun(()-> NioCF.close(clientChannel));
                       } else {
                           String response = "wrong command";
                           if ("1".equals(msg))
                               response = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                           response += "\n"+MENU;
                           return NioCF.write(response, clientChannel)
                                   .thenCompose((Void v) -> dialog(clientChannel));
                       }
                   });
    }


    public static void main (String [] args)
            throws ExecutionException, InterruptedException, IOException {

        try(AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open()) {
            InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
            serverChannel.bind(hostAddress);
            System.out.println("Server channel bound to port: " + hostAddress.getPort());

            nextClient(serverChannel).get();

//            while (true) {
//                nextClient(serverChannel).get();
//            }


        }

    }
}