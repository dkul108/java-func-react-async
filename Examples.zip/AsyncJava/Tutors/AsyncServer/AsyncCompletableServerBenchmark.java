import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Task: Use CompletionHandler and CompletableFuture for AsyncServer
 * Implement possibility to use menu to retrieve information from the server:
 * 1) Get current time
 * 2) Exit
 *
 */
public class AsyncCompletableServerBenchmark {

    static String MENU = "1) Get current time\n2) Exit\n";
    static AtomicInteger clientsAmount = new AtomicInteger(0);
    static Thread killer = new Thread(() -> {
        System.out.println("killer started");
        try {
            Thread.sleep(100_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(clientsAmount + " clients was able to connect during 3 seconds ");
        System.exit(0);
    });

    static ExecutorService executor = Executors.newCachedThreadPool(); //max 10 threads
    public static CompletableFuture<Void> nextClient(AsynchronousServerSocketChannel serverChannel) {
        return NioCF.acceptClient(serverChannel)
                .thenAcceptAsync(clientChannel -> {
                    NioCF.write(MENU, clientChannel)
                        .thenCompose((Void v) -> dialog(clientChannel));
                })
                .thenRun(()->{if (!killer.isAlive()&&clientsAmount.get()>0) killer.start();})
                //.thenRun(()-> clientsAmount.incrementAndGet())

                // also we are able to use recursion instead of while(true)
                .thenCompose((Void v)->nextClient(serverChannel));
    }

    public static CompletableFuture<Void> dialog(AsynchronousSocketChannel clientChannel) {
            return NioCF.read(clientChannel) // read menu choice
                   .thenCompose(msg->{
                       if ("2".equals(msg)) {
                           return NioCF.write("bye", clientChannel)
                                   .thenRun(()-> {
                                       //System.out.println("Client disconnected");
                                       clientsAmount.incrementAndGet();
                                       NioCF.close(clientChannel);
                                   });
                       } else {
                           String response = "wrong command";
                           if ("1".equals(msg))
                               response = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                           response += "\n"+MENU;
                           return NioCF.write(response, clientChannel)
                                   .thenCompose((Void v) -> dialog(clientChannel));
                       }
                   });
    }


    public static void main (String [] args)
            throws ExecutionException, InterruptedException, IOException {

        try(AsynchronousServerSocketChannel serverChannel = AsynchronousServerSocketChannel.open()) {
            InetSocketAddress hostAddress = new InetSocketAddress("localhost", 3883);
            serverChannel.bind(hostAddress);
            System.out.println("Server channel bound to port: " + hostAddress.getPort());

//            nextClient(serverChannel).get();

            while (true) {
                nextClient(serverChannel).get();
            }


        }

    }
}