import java.io.File;
import java.io.IOException;

public class Benchmark {

    public static Process exec(Class klass) throws IOException,
            InterruptedException {
        String javaHome = System.getProperty("java.home");
        String javaBin = javaHome +
                File.separator + "bin" +
                File.separator + "java";
        String classpath = System.getProperty("java.class.path");
        String className = klass.getCanonicalName();

        ProcessBuilder builder = new ProcessBuilder(
                javaBin, "-noverify", "-cp", classpath, className);

        Process process = builder.inheritIO().start();
        return process;
    }

    public static void main(String[] args) throws Exception {
        for (int i=0;i<1;i++) {
            Process server = exec(AsyncCompletableServerBenchmark.class);
            Thread.sleep(100);
            Process client = exec(AsyncCompletableClientBenchmark2.class);
            client.waitFor();
            server.waitFor();
        }
    }
}
