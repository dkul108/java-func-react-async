import java.io.File;
import java.io.IOException;

public class BenchmarkOldIO {

    public static Process exec(Class klass) throws IOException,
            InterruptedException {
        String javaHome = System.getProperty("java.home");
        String javaBin = javaHome +
                File.separator + "bin" +
                File.separator + "java";
        String classpath = System.getProperty("java.class.path");
        String className = klass.getCanonicalName();

        ProcessBuilder builder = new ProcessBuilder(
                javaBin, "-noverify", "-cp", classpath, className);

        Process process = builder.inheritIO().start();
        return process;
    }
    static Thread timer = new Thread(() -> {
        try {
            Thread.sleep(30_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("time finished");
        System.exit(0);
    });

    public static void main(String[] args) throws Exception {
        for (int i=0;i<1;i++) {
            Process server = exec(ServerBenchmark.class);
            Thread.sleep(100);
            Process client = exec(ClientBenchmark.class);
            //timer.start();
            client.waitFor();
            server.waitFor();
        }
    }
}
