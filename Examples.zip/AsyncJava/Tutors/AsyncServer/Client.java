import java.io.*;
import java.net.Socket;

/**
 * Created by vladson on 7/1/17.
 */
public class Client {
    public static void main(String[] args) throws Exception {
        try (Socket socket = new Socket("localhost",3883)) {
            InputStream in = socket.getInputStream();
            OutputStream out = socket.getOutputStream();
            BufferedReader bin = new BufferedReader(
                    new InputStreamReader(in));
            BufferedWriter bout = new BufferedWriter(
                    new OutputStreamWriter(out));
            byte[] buf = new byte[100];
            int size = in.read(buf);
            String menu = new String(buf, 0, size);
            System.out.println(menu);

            try (BufferedReader r = new BufferedReader(new InputStreamReader(System.in))) {
                while(true) {
                    String msg = r.readLine();
                    bout.write(msg); // send choice to server
                    bout.flush();
                    byte[] buf2 = new byte[100];
                    size = in.read(buf2);
                    if (size>0) {
                        String answer = new String(buf2, 0, size);
                        System.out.println(answer);
                        if ("bye".equals(answer)) return;
                    }
                }
            }
        }
    }
}
