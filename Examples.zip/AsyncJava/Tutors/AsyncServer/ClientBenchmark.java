import java.io.*;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by vladson on 7/1/17.
 */
public class ClientBenchmark {
    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        AtomicInteger processedClients = new AtomicInteger(0);

        Runnable runnable = () -> {
            try (Socket socket = new Socket("localhost", 3884);
                 InputStream in = socket.getInputStream();
                 OutputStream out = socket.getOutputStream();
                 BufferedWriter bout = new BufferedWriter(
                         new OutputStreamWriter(out));) {

                byte[] buf = new byte[100];
                int size = in.read(buf);
                String menu = new String(buf, 0, size);
                //System.out.println(menu);

                try (BufferedReader r = new BufferedReader(new InputStreamReader(System.in))) {
                    while (true) {
                        //String msg = r.readLine();
                        //bout.write(msg); // send choice to server
                        bout.write("2");
                        bout.flush();
                        byte[] buf2 = new byte[100];
                        size = in.read(buf2);
                        if (size > 0) {
                            String answer = new String(buf2, 0, size);
                            //System.out.println(answer);
                            if ("bye".equals(answer)) {
                                processedClients.incrementAndGet();
                                return;
                            }
                        }
                    }
                }
            } catch(Exception e) {
                if (!executorService.isShutdown()) {
                    e.printStackTrace();
                    executorService.shutdownNow();
                }
                return;
            }
        };

        for (int i = 0; i < 50000; i++) {
            if (!executorService.isShutdown()) {
                executorService.submit(runnable);
                //Thread.sleep(10);
            }
        }
        executorService.awaitTermination(100, TimeUnit.SECONDS);
        System.out.println("Server processed "+processedClients.get()+" clients");


    }
}
