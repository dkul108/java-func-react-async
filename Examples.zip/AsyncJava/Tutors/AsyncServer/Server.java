import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by vladson on 7/1/17.
 */
public class Server {
    static String MENU = "1) Get current time\n2) Exit";

    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        int PORT = 3883;
        ServerSocket socket = new ServerSocket(PORT);
        System.out.println("Server channel bound to port: "+PORT);
        while(true) {
            Socket accept = socket.accept();
            System.out.println("Client connected");
            InputStream in = accept.getInputStream();
            OutputStream out = accept.getOutputStream();
            BufferedReader bin = new BufferedReader(
                    new InputStreamReader(in));
            BufferedWriter bout = new BufferedWriter(
                    new OutputStreamWriter(out));
            bout.write(MENU);
            bout.flush();
            executorService.execute(() -> {
                while(true) {
                    try {
                        byte[] buf = new byte[100];
                        int size = in.read(buf);
                        String msg = new String(buf, 0, size);
                        if ("2".equals(msg)) {
                            bout.write("bye");
                            bout.flush();
                            return;
                        } else if ("1".equals(msg)) {
                            String response =
                                    LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                            response += "\n" + MENU;
                            bout.write(response);
                            bout.flush();
                        } else {
                            bout.write("wrong command");
                            bout.flush();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
