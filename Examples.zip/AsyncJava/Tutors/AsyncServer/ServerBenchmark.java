import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by vladson on 7/1/17.
 */
public class ServerBenchmark {
    static String MENU = "1) Get current time\n2) Exit";
    static AtomicInteger clientsAmount = new AtomicInteger(0);
    static Thread killer = new Thread(() -> {
        try {
            Thread.sleep(50_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(clientsAmount + " clients was able to connect during 10 seconds ");
        System.exit(0);
    });

    public static void main(String[] args) throws Exception {
        ExecutorService executorService = Executors.newFixedThreadPool(100);
        int PORT = 3884;
        ServerSocket socket = new ServerSocket(PORT);
        System.out.println("Server channel bound to port: "+PORT);
        while(true) {
            Socket accept = socket.accept();
            if (!killer.isAlive()) killer.start();

            //System.out.println("Client connected");
            InputStream in = accept.getInputStream();
            OutputStream out = accept.getOutputStream();

            BufferedWriter bout = new BufferedWriter(
                    new OutputStreamWriter(out));
            bout.write(MENU);
            bout.flush();
            executorService.execute(() -> {
                while(true) {
                    try {
                        byte[] buf = new byte[100];
                        int size = in.read(buf);
                        String msg = new String(buf, 0, size);
                        if ("2".equals(msg)) {
                            bout.write("bye");
                            bout.flush();
                            clientsAmount.incrementAndGet();
                            return;
                        } else if ("1".equals(msg)) {
                            String response =
                                    LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
                            response += "\n" + MENU;
                            bout.write(response);
                            bout.flush();
                        } else {
                            bout.write("wrong command");
                            bout.flush();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
