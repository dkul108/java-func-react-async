package completable;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;
import static org.junit.Assert.*;

public class ComposeTutor extends CompletableFutureBase {

	public CompletableFuture<Integer> getSlow() {
		System.out.println("getSlow started..");
		try { Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("getSlow completed");
		return CompletableFuture.completedFuture(1);
	}
	public CompletableFuture<Integer> incSlow(int i) {
		System.out.println("incSlow started");
		try { Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("incSlow completed");
		return CompletableFuture.completedFuture(i+1);
	}

	public static void main(String[] args) {
		ComposeTutor t = new ComposeTutor();
		t.getSlow()
			.thenApply(t::incSlow)
			.thenAccept(System.out::println);
	}

	/**
	 * 1) Use future1.thenCompose() to put result of future1 into thenCompose
	 * 2) perform slowIncrement for thenCompose
	 * 
	 */
	@Test
	public void promiseTestCompose2() throws Exception {
		CompletableFuture<Integer> future1 = 
				CompletableFuture.supplyAsync(this::slowInit) // 1 
					.thenApply(this::slowIncrement); // 2

		CompletableFuture<Integer> thenCompose = null;
		
		int result = thenCompose.get();
		System.out.println(result);
		assertEquals(result, 3);
	}

}
