package completable;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;

public class ExceptionTutor extends CompletableFutureBase {
    @Test
    public void testThenCombineSync() throws Exception {
        CompletableFuture<Integer> future =
                CompletableFuture.supplyAsync(this::slowInit)
                        .thenApply(this::slowIncrementException)
                        .thenApply(this::slowIncrement)
                        // this function will be executed only in case of Exception
                        .exceptionally(ex -> {
                            System.out.println("exception happened!");
                            if (ex.getCause() instanceof MyException) {
                                return ((MyException)ex).lastValue;
                            } else return 0;
                        })
                        .thenApply(this::slowIncrementException)
                        .exceptionally(ex -> {
                            System.out.println("exception happened 2!");
                            return 2;
                        })
                        .thenApply(this::slowIncrement)
                ;
        Integer result = future.get();
        System.out.println(result);


    }
}
