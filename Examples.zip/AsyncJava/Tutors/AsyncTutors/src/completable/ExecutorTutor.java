package completable;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorTutor extends CompletableFutureBase {
    public void test() {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        CompletableFuture<Integer> future =
                CompletableFuture.supplyAsync(this::slowInit, executorService)
                        .thenApplyAsync(this::slowIncrement, executorService);
    }

    public CompletableFuture<String> getCF() {
        CompletableFuture<String> cf = new CompletableFuture<>();
        Runnable r = ()->{
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
                cf.completeExceptionally(e);
            }
            cf.complete("result");
        };
        new Thread(r).start();
        return cf;
    }

    public CompletableFuture<String> getCF2() {
        return CompletableFuture.completedFuture("ended");
    }

    @Test
    public void obtrude() {
        //if (getCF().isDone()) res = getCF().get(); else res = "not ready";
        System.out.println(getCF().getNow("not ready"));
        CompletableFuture<String> cf = getCF();
        try {
            System.out.println(cf.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        System.out.println(cf.getNow("not ready"));

        cf.obtrudeValue("nothing");
        System.out.println(cf.getNow("no result"));
    }

    public static void main(String[] args) {
        new ExecutorTutor().test();
    }
}
