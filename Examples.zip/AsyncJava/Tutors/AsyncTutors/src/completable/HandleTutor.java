package completable;

import org.junit.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

public class HandleTutor extends CompletableFutureBase {
	
	/**
	 * Modify this example by using asynchronous calls so that it was 
	 * executing in 2 seconds 
	 */
	@Test
	public void testThenCombineSync() throws Exception {
		  long start = System.nanoTime();   

		  CompletableFuture<String> cf =
			CompletableFuture.supplyAsync(()-> {
						if (Math.random() < 0.01)
							throw new RuntimeException("failed");
						return "success";
					}
			);

		cf.cancel(true);

		System.out.println(cf.handle((String res,Throwable ex)->
				  {
				  	if (ex!=null) System.out.println(ex.getMessage());
				  	else System.out.println(res);
				  	return ex!=null?ex.getMessage():res;
				  }
		  ).get());


		} 

}
