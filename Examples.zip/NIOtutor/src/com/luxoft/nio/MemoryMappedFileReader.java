package com.luxoft.nio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MemoryMappedFileReader {

    public static void readFile() throws FileNotFoundException, IOException {
        File f = new File("mapped.txt");
        f.delete();
        FileChannel fc =
                new RandomAccessFile(f, "rw")
                .getChannel();

        long bufferSize=8*1000;
        System.out.println("waiting for file data...");
        while (fc.size()<bufferSize);

        System.out.println("got some data of size " + fc.size());
        MappedByteBuffer mem = fc.map(
                FileChannel.MapMode.READ_ONLY,
                0, bufferSize);
        long size = 0;
        long lastValue = -1;
        int currentPos = 0;
        long position = 0;
        while (true) {
            while (mem.hasRemaining()) {
                lastValue = mem.getLong();
                currentPos += Long.BYTES;
                mem.position(currentPos);
                System.out.println(lastValue);
            }

            if (fc.size()>position+bufferSize) {
                size = fc.size();
                //System.out.println("size="+size);
                //System.out.println("reading next portion of 8000 bytes, lastValue = "+lastValue);
                position += mem.position();
                System.out.println("mem position = "+position);
                mem = fc.map(FileChannel.MapMode.READ_ONLY, position, bufferSize);
                currentPos = 0;
            } else if (fc.size()>position){
                position += mem.position();
                mem = fc.map(FileChannel.MapMode.READ_ONLY, position, fc.size()-position);
                currentPos = 0;
            } else if (fc.size()==position) {
                // waiting for the next portion of data
                while (fc.size() == position) {
                    System.out.print(".");
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }



        }

    }

    public static void main(String[] args) throws Exception {
        readFile();
    }

}
