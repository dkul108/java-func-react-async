package com.luxoft.nio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MemoryMappedFileWriter {

    public static void writeFile() throws IOException {
        File f = new File("mapped.txt");

        FileChannel fc =
                new RandomAccessFile(f, "rw")
                        .getChannel();

        System.out.println(fc.size());
        long bufferSize=8*1000;
        long position = fc.size();
        MappedByteBuffer mem =fc.map(
                FileChannel.MapMode.READ_WRITE,
                position, bufferSize);

        long start = position;
        long counter=1;
        long noOfMessage = 100_000_000;
        while(true) {
            if(!mem.hasRemaining()) {
                start += mem.position();
                mem = fc.map(FileChannel.MapMode.READ_WRITE,
                        start, bufferSize);
            }
            mem.putLong(counter);
            counter++;
            if (counter > noOfMessage ) break;
        }
        System.out.println("size = "+fc.size());
    }


    public static void main(String[] args) throws Exception {
        writeFile();
    }

}
