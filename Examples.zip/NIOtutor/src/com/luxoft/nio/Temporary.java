package com.luxoft.nio;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class Temporary {

    public static void main(String[] args) {

        // creating temporary folders
        String tmp_dir_prefix = "nio_";
        try {
            //passing null prefix
            Path tmp_1 = Files.createTempDirectory(null);
            System.out.println("TMP: " + tmp_1.toString());

            //set a prefix
            Path tmp_2 = Files.createTempDirectory(tmp_dir_prefix);
            System.out.println("TMP: " + tmp_2.toString());
        } catch (IOException e) {
            System.err.println(e);
        }


        // create temporary folder and auto-delete it
        Path basedir = FileSystems.getDefault().getPath(".");

        try {
            //create a tmp directory in the base dir
            Path tmp_dir = Files.createTempDirectory(basedir, tmp_dir_prefix);
            System.out.println("TMP: " + tmp_dir.toAbsolutePath());
            File asFile = tmp_dir.toFile();
            asFile.deleteOnExit();

            Thread.sleep(100000);

        } catch (IOException | InterruptedException e) {
            System.err.println(e);
        }


        // temporary file deleted with the hook

        String tmp_file_prefix = "nio_";
        String tmp_file_sufix = ".txt";

        try {
            final Path tmp_file = Files.createTempFile(basedir, tmp_file_prefix, tmp_file_sufix);

            System.out.println("created temporary file "+tmp_file.toAbsolutePath());
            Runtime.getRuntime().addShutdownHook(new Thread() {

                @Override
                public void run() {
                    System.out.println("Deleting the temporary file ...");

                    try {
                        Files.delete(tmp_file);
                    } catch (IOException e) {
                        System.err.println(e);
                    }

                    System.out.println("Shutdown hook completed...");
                }
            });
            Thread.sleep(10000);

        } catch (IOException | InterruptedException e) {
            System.err.println(e);
        }

    }
}
