package com.luxoft.nio.netty;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * Implementing TIME protocol.
 * Server sends a message, which contains a 32-bit integer,
 * without receiving any requests and closes the connection
 * once the message is sent.
 */
public class NettyTimeServerHandler extends ChannelInboundHandlerAdapter {

    @Override
    // channelActive() method will be invoked when
    // a connection is established and ready to generate traffic
    public void channelActive(final ChannelHandlerContext ctx) {
        // We are going to write a 32-bit integer, and therefore
        // we need a ByteBuf whose capacity is at least 4 bytes
        final ByteBuf time = ctx.alloc().buffer(4);
        time.writeInt((int)
                (System.currentTimeMillis() / 1000L + 2208988800L));

        final ChannelFuture f = ctx.writeAndFlush(time);
        f.addListener(new ChannelFutureListener() {
            @Override
            public void operationComplete(ChannelFuture future) {
                assert f == future;
                ctx.close();
            }
        });
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }

}
