package com.luxoft.reactor.basics;

import reactor.core.publisher.Flux;

public class SimplestDemo {
    public static void main(String[] args) {
        Flux<String> locations =
            Flux.just("Bucharest",
                    "Krakow", "Moscow",
                    "Kiev", "Sofia"); //declaration
        locations.subscribe(System.out::println);

    }
}
