package com.luxoft.reactor.basics;

import reactor.core.publisher.Flux;

public class SubscribeDemo {

    public static void main(String[] args) {
        Flux<String> locations =
                Flux.just("Bucharest", "Krakow", "Moscow", "Kiev",
                        "Sofia");
        locations.map(String::length).filter(l -> l >= 5)
                .subscribe(l -> System.out.println("Length: " + l),
                        Throwable::printStackTrace,
                        () -> System.out.println("Done."));

        locations.map(String::length).filter(l -> l >= 5)
                .subscribe(l -> System.out.println("Length: " + l),
                        Throwable::printStackTrace);

    }
}
