package com.luxoft.rxjava;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observables.ConnectableObservable;
import io.reactivex.schedulers.Schedulers;

import java.math.BigDecimal;
import java.util.Random;

public class FirstTask {

    public static void main(String[] args) throws InterruptedException {
        first();
        second();
        third();
        forth();
        fifth();
        sixth();
        seventh();
        eighth();
        ninth();
        tenth();
        eleventh();
        twelfth();
    }

    /**
     * Create observable which will emit operations on
     * bank account (cash deposit and withdrawal)
     * at some random moments - use create(), onNext()
     * and Thread.sleep() for delays:
     * 	[+100, +1000, -200, -300]
     */
    private static void first() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.subscribe(it -> System.out.println("1) Created observable: " + it));
    }

    /**
     * Use filter() to show only deposits
     */
    private static void second() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.filter(it -> it.compareTo(BigDecimal.ZERO) > 0)
                .subscribe(it -> System.out.println("2) Only deposits: " + it));
    }

    /**
     * Use map() to transform values in cents (multiply by 100)
     */
    private static void third() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.map(it -> it.multiply(new BigDecimal("100")))
                .subscribe(it -> System.out.println("3) Cents: " + it));
    }

    /**
     * Throw error in the observable with onError,
     * print error details by subscribing to onError hook
     */
    private static void forth() {
        final Observable<BigDecimal> transactionsWithError = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> emitter.onError(new Exception())
        ).publish().refCount();

        transactionsWithError.subscribe(
                it -> System.out.println("4) Do something"),
                error -> System.out.println("4) onError hook: " + error)
        );
    }

    /**
     * Add onComplete() and add onCompete() hook to subscribe method
     */
    private static void fifth() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.subscribe(
                it -> System.out.print(""),
                error -> System.out.println("5) Oops, something went wrong"),
                () -> System.out.println("5) onComplete hook")
        );
    }

    /**
     * Use Disposable to unsubscribe from observable
     * after some time and stop to get messages
     * @throws InterruptedException
     */
    private static void sixth() throws InterruptedException {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).subscribeOn(Schedulers.computation()).publish().refCount();

        final Disposable disposable = transactions.subscribe(it -> System.out.println("6) " + it));

        Thread.sleep(3000);
        disposable.dispose();
        System.out.println("6) Unsubscribed");
    }

    /**
     * Use side effect methods to print elements before filtering,
     * before mapping and in case of error (use doOnNext(), doOnError)
     */
    private static void seventh() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.doOnNext(it -> System.out.println("7) before filtering"))
                .filter(it -> {
                    System.out.println("7) filtering");
                    return it.compareTo(BigDecimal.ZERO) > 0;
                })
                .doOnNext(it -> System.out.println("7) before mapping"))
                .map(it -> {
                    System.out.println("7) mapping " + it);
                    return it.toString();
                })
                .doOnNext(it -> {
                    throw new Exception();
                })
                .doOnError(error -> System.out.println("7) onError"))
                .onErrorReturnItem("")
                .subscribe();
    }

    /**
     * In case of error replace it by 0 (use onErrorReturn())
     */
    private static void eighth() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onError(new Exception());
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.onErrorReturn(it -> BigDecimal.ZERO).subscribe(it -> System.out.println("8) Data is: " + it));
    }

    /**
     * Transform observable to shared
     * and perform multiple subscriptions to it
     */
    private static void ninth() {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).share();

        transactions.subscribe(it -> System.out.println("9) First sub: " + it));
        transactions.subscribe(it -> System.out.println("9) Secong sub: " + it));
    }

    /**
     * Make observable connectable, subscribe to it
     * using several subscription and connect() to it after delay
     * @throws InterruptedException
     */
    private static void tenth() throws InterruptedException {
        final ConnectableObservable<Object> transactions = Observable.create(
                emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish();

        transactions.subscribe(it -> System.out.println("10) First sub: " + it));
        transactions.subscribe(it -> System.out.println("10) Second sub: " + it));

        System.out.println("10) Attempting to connect...");
        Thread.sleep(new Random().nextInt(2000));
        transactions.connect();
    }

    /**
     * Postpone creating of observable (use defer()),
     * make a pause before subscriptions
     * @throws InterruptedException
     */
    private static void eleventh() throws InterruptedException {
        final Observable<BigDecimal> transactions = Observable.defer(
                () -> Observable.create(
                        emitter -> {
                            Thread.sleep(new Random().nextInt(2000));
                            emitter.onNext(new BigDecimal("100"));
                            Thread.sleep(new Random().nextInt(2000));
                            emitter.onNext(new BigDecimal("1000"));
                            Thread.sleep(new Random().nextInt(2000));
                            emitter.onNext(new BigDecimal("-200"));
                            Thread.sleep(new Random().nextInt(2000));
                            emitter.onNext(new BigDecimal("-300"));
                            Thread.sleep(new Random().nextInt(2000));
                            emitter.onComplete();
                        })
        );

        Thread.sleep(new Random().nextInt(2000));
        System.out.println("11) First subscription");
        transactions.subscribe(it -> System.out.println("11) First sub: " + it));
        System.out.println("11) Second subscription");
        transactions.subscribe(it -> System.out.println("11) Second sub: " + it));
    }

    /**
     * Keep disposables from all subscriptions,
     * make composite from all of them cancel all of them at once
     * @throws InterruptedException
     */
    private static void twelfth() throws InterruptedException {
        final Observable<BigDecimal> transactions = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("100"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1000"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-200"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-300"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).subscribeOn(Schedulers.computation()).share();

        final Disposable firstSubscriber = transactions.subscribe(it -> System.out.println("12) First sub: " + it));
        final Disposable secondSubscriber = transactions.subscribe(it -> System.out.println("12) Second sub: " + it));

        Thread.sleep(1000);
        final CompositeDisposable disposables = new CompositeDisposable();
        disposables.addAll(firstSubscriber, secondSubscriber);
        Thread.sleep(1000);
        System.out.println("12) Disposing all");
        disposables.dispose();
    }
}
