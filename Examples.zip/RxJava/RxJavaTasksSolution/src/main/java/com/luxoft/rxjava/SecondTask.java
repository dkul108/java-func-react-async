package com.luxoft.rxjava;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.observables.ConnectableObservable;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.PublishSubject;
import io.reactivex.subjects.ReplaySubject;

import java.math.BigDecimal;
import java.util.AbstractMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class SecondTask {

    private static final Observable<BigDecimal> transactions = Observable.create(
            (ObservableOnSubscribe<BigDecimal>) emitter -> {
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("100"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("1000"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("-200"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("-300"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onComplete();
            }).publish().refCount();

    private static final Observable<BigDecimal> cache = Observable.create(
            (ObservableOnSubscribe<BigDecimal>) emitter -> {
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("1"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("2"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("-3"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onNext(new BigDecimal("-4"));
                Thread.sleep(new Random().nextInt(2000));
                emitter.onComplete();
            }).publish().refCount();

    public static void main(String[] args) throws InterruptedException {
        first();
        second();
        third();
        forth();
        fifth();
        sixth();
        seventh();
        eighth();
        ninth();
        tenth();
        eleventh();
        twelfth();
    }

    /**
     * Use groupBy to print separately all deposits and all withdrawals
     */
    private static void first() {
        transactions.groupBy(it -> it.compareTo(BigDecimal.ZERO) > 0)
                .subscribe(group -> {
                    System.out.println("1) Group: " + group.getKey());
                    group.subscribe(it -> System.out.println("1) GroupBy: " + it));
                });
    }

    /**
     * Use scan to calculate and print the current account state
     */
    private static void second() {
        transactions.scan(BigDecimal::add).subscribe(it -> System.out.println("2) Account state: " + it));
    }

    /**
     * Use timestamp to print the moment when operation was emitted
     */
    private static void third() {
        transactions.timestamp().subscribe(it -> System.out.println("3) Info with time: " + it));
    }

    /**
     * Use count to calculate amount of withdraw and deposits
     * (separately, pass function to count())
     */
    private static void forth() {
        transactions.groupBy(it -> it.compareTo(BigDecimal.ZERO) > 0)
                .subscribe(group -> group.count()
                        .subscribe(it -> System.out.println("4) Key=" + group.getKey() + " Count=" + it))
                );
    }

    /**
     * Convert to multi map, containing all withdrawals and all deposits separately
     */
    private static void fifth() {
        transactions.toMultimap(it -> it.compareTo(BigDecimal.ZERO) > 0 ? "Deposits" : "Withdrawals")
                .subscribe(it -> System.out.println("5) Map: " + it));
    }

    /**
     * Create another observable emitting cash operations,
     * use merge to show operations in both observables
     */
    private static void sixth() {
        transactions.mergeWith(cache).subscribe(it -> System.out.println("6) Merged: " + it));
    }

    /**
     * Create method Observable<String> remoteProcess(int amount)
     * which will «process» operation by adding braces
     * like (100) (200) with some delay imitating server delay
     * (use sleep) and returning Observable<String>.
     * Use it process all cash operations (use flatMap)
     */
    private static void seventh() {
        cache.flatMap(it -> remoteProcess(it.intValue()))
                .subscribe(it -> System.out.println("7) Processed by remote: " + it));
    }

    private static Observable<String> remoteProcess(int amount) {
        return Observable.just("(" + amount + ")").delay(1000, TimeUnit.MILLISECONDS);
    }

    /**
     * Create a separate observable with approvals
     * (like [ true, true, false, true ]),
     * use zip to combine it with operations,
     * remove operations which was not approved
     */
    private static void eighth() {
        final Observable<Boolean> approvals = Observable.create(
                (ObservableOnSubscribe<Boolean>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(Boolean.TRUE);
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(Boolean.TRUE);
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(Boolean.FALSE);
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(Boolean.TRUE);
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onComplete();
                }).publish().refCount();

        transactions.zipWith(approvals, (transaction, approval) -> new AbstractMap.SimpleEntry<>(approval, transaction))
                .filter(AbstractMap.SimpleEntry::getKey).subscribe(it -> System.out.println("8) Approved: " + it));
    }

    /**
     * Create observable with information about the client,
     * like [“Ivan”, “Maria”] use combineLatest to add information
     * about the client to the cash operations.
     * Client’s name should change after some delay.
     * @throws InterruptedException
     */
    private static void ninth() throws InterruptedException {
        final Observable<String> clients = Observable.create(
                (ObservableOnSubscribe<String>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext("Ivan");
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext("Maria");
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext("Ivan");
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext("Maria");
                    emitter.onComplete();
                }).publish().refCount();

        final Observable<BigDecimal> localCache = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("2"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-3"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-4"));
                    emitter.onComplete();
                }).subscribeOn(Schedulers.computation()).publish().refCount();

        Observable.combineLatest(localCache, clients, (cache, client) -> client + " - " + cache)
                .subscribe(it -> System.out.println("9) Clients with cache " + it));
    }

    /**
     * Use replay() to reproduce previous operations
     * if the subscriber has connected lately.
     * Do some delay and connect the second subscriber,
     * check that it has received all messages.
     * @throws InterruptedException
     */
    private static void tenth() throws InterruptedException {
        final ConnectableObservable<BigDecimal> localCache = Observable.create(
                (ObservableOnSubscribe<BigDecimal>) emitter -> {
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("1"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("2"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-3"));
                    Thread.sleep(new Random().nextInt(2000));
                    emitter.onNext(new BigDecimal("-4"));
                    emitter.onComplete();
                }).replay();

        localCache.subscribe(it -> System.out.println("10) Subscriber 1: " + it));
        localCache.connect();
        Thread.sleep(3000);
        localCache.subscribe(it -> System.out.println("10) Subscriber 2: " + it));
    }

    /**
     * Convert observable to PublishSubject,
     * make possibility to perform cash operations with this subject
     */
    private static void eleventh() {
        final PublishSubject<BigDecimal> localCache = PublishSubject.create();

        localCache.subscribe(it -> System.out.println("11) Subscriber 1: " + it));
        localCache.onNext(BigDecimal.ZERO);
        localCache.onNext(BigDecimal.ONE);
        localCache.subscribe(it -> System.out.println("11) Subscriber 2: " + it));
        localCache.onNext(BigDecimal.TEN);
        localCache.onComplete();
    }

    /**
     * Use Replay subject to be able to reproduce
     * operations for the late subscribers
     */
    private static void twelfth() {
        final ReplaySubject<BigDecimal> localCache = ReplaySubject.create();

        localCache.subscribe(it -> System.out.println("12) Subscriber 1: " + it));
        localCache.onNext(BigDecimal.ZERO);
        localCache.onNext(BigDecimal.ONE);
        localCache.onNext(BigDecimal.TEN);
        localCache.onComplete();
        localCache.subscribe(it -> System.out.println("12) Subscriber 2: " + it));
    }
}
