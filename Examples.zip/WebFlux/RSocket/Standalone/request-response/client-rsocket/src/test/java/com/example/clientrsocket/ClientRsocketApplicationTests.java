package com.example.clientrsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientRsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
