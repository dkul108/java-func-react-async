package com.example.serverrsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
