package com.luxoft.webflux.rsocket;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.luxoft.webflux.domain.Person;
import io.netty.handler.ssl.SslContextBuilder;
import io.rsocket.RSocket;
import io.rsocket.RSocketFactory;
import io.rsocket.client.LoadBalancedRSocketMono;
import io.rsocket.client.filter.RSocketSupplier;
import io.rsocket.core.RSocketConnector;
import io.rsocket.frame.decoder.PayloadDecoder;
import io.rsocket.transport.netty.client.TcpClientTransport;
import org.reactivestreams.Publisher;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.messaging.rsocket.DefaultMetadataExtractor;
import org.springframework.messaging.rsocket.MetadataExtractor;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.messaging.rsocket.RSocketStrategies;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;
import org.springframework.util.RouteMatcher;
import org.springframework.web.util.pattern.PathPatternRouteMatcher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.tcp.InetSocketAddressUtil;
import reactor.netty.tcp.SslProvider;
import reactor.netty.tcp.TcpClient;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

import static io.rsocket.client.LoadBalancedRSocketMono.*;

public class RSocketLBClient {
    public static final String MIME_ROUTER = "message/x.rsocket.composite-metadata.v0";
    private static Logger log = (Logger) LoggerFactory.getLogger("ROOT");
    static {
        log.setLevel(Level.INFO); // turn off all DEBUG logging
    }

    public static void main(String[] args) throws InterruptedException, IOException {
        RSocketStrategies strategies = RSocketStrategies.builder()
                .encoders(encoders -> encoders.add(new Jackson2JsonEncoder()))
                .decoders(decoders -> decoders.add(new Jackson2JsonDecoder()))
                .build();

        Function<Integer, RSocket> getConnector = port -> RSocketConnector
                .create()
                .dataMimeType(MimeTypeUtils.APPLICATION_JSON_VALUE)
                .metadataMimeType(MIME_ROUTER)
                .connect(TcpClientTransport.create(port))
                .doOnSubscribe(s -> System.out.println("RSocket connection established on port " + port))
                .block();

        List<RSocketSupplier> socketSuppliers = Flux.just(7000, 7001)
            .map(port -> new RSocketSupplier(
                ()->Mono.just(getConnector.apply(port))))
            .collectList().block();

        LoadBalancedRSocketMono balancer =
                LoadBalancedRSocketMono
                    .create(Flux.just(socketSuppliers));

        AtomicInteger id = new AtomicInteger(1);
        Flux.range(1,4)
                .flatMap(i -> balancer)
                .map(rSocket ->
                    RSocketRequester.wrap(rSocket,
                        MimeTypeUtils.APPLICATION_JSON,
                        MimeType.valueOf(MIME_ROUTER),
                        strategies))
                .doOnNext(rSocket -> rSocket
                        .route("findById2")
                        .data(id.getAndIncrement())
                        .retrieveMono(Person.class)
                        .doOnNext(System.out::println)
                        .block()
                        )
                .blockLast();

    }
}
