Docker command to create Rabbit MQ queue

docker run -d --hostname my-rabbit --name sample-rabbit -p 15672:15672 -p 5671:5671 -p 5672:5672 rabbitmq:3-management

Create a queue with the name movie-event-queue

URLs:
http://localhost:8080/movies
http://localhost:8080/movies/{id}/cities
http://localhost:8080/movies/cities
