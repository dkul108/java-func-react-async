package com.luxoft.webflux;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.luxoft.webflux.model.Person;
import com.luxoft.webflux.repository.PersonRepository;

import reactor.core.publisher.Flux;

@Component
public class Bootstrap implements CommandLineRunner {

	private final PersonRepository personRepository;

	public Bootstrap(PersonRepository personRepository) {
		this.personRepository = personRepository;
	}

	@Override
	public void run(String... args) throws Exception {
		// clear old data
		personRepository.deleteAll()
			.thenMany(Flux
					.just("Vasiliy",
							"Dmitriy",
							"Ivav")
					.map(name -> new Person(name))
					.flatMap(personRepository::save))
			.subscribe(null, null, () -> {
				personRepository
						.findAll()
						.subscribe(System.out::println);
			});
	}
}