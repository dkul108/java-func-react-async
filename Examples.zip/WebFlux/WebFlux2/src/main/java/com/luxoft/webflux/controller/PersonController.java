package com.luxoft.webflux.controller;

import com.luxoft.webflux.model.Person;
import com.luxoft.webflux.model.PersonEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.luxoft.webflux.service.PersonService;

import reactor.core.publisher.*;

@RestController
@RequestMapping("/persons")
public class PersonController {

    private final PersonService personService;
    private ReplayProcessor<PersonEvent> personsProcessor  =
            ReplayProcessor.create();

    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    @GetMapping(value = "/cities", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<PersonEvent> getPersonCities() {
        return this.personsProcessor;
    }

    @RabbitListener(queues = "${person.event.queue.name}")
    public void onRabbitMessage(PersonEvent personEvent) {
        this.personsProcessor.onNext(personEvent);
    }

    @GetMapping(value = "/{id}/cities", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    Flux<PersonEvent> streamPersonCities(@PathVariable String id){
        return personService.cities(id);
    }

    @GetMapping(value = "/{id}")
    Mono<Person> getPersonById(@PathVariable String id){
        return personService.getPersonById(id);
    }

    @GetMapping
    Flux<Person> getAllPersons(){
        return personService.getAllPersons();
    }
}